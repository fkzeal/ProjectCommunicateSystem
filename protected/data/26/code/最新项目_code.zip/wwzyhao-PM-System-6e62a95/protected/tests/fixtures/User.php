<?php

return array(
	/*
	'sample1'=>array(
		'username' => '',
		'password' => '',
		'age' => '',
	),
	'sample2'=>array(
		'username' => '',
		'password' => '',
		'age' => '',
	),
	*/
);
