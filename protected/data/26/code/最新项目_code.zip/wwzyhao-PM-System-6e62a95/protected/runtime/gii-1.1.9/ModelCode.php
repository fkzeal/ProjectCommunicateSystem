<?php
return array (
  'template' => 'default',
  'tablePrefix' => '',
  'modelPath' => 'application.models',
  'baseClass' => 'CActiveRecord',
  'buildRelations' => '1',
);
